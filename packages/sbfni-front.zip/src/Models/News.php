<?php
namespace Breakit\Sbfni\Sbfnifront\Models;
        
use Breakit\Sbfni\Sbfnifront\Models\Sbfnifront;



class News extends Sbfnifront
{
    
    
    protected $connection   =   '';
    protected $table = 'news';
    protected $guarded = [];
    //protected $fillable = [ 'columnOne', 'columnTwo', 'columnThree' ];
    /* Eloquent Relationship */
    ##ELOQUENTRELATIONSHIPMODEL##

}
