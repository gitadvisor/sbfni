<?php
namespace Breakit\Sbfni\Sbfnifront\Models;
        
use Breakit\Sbfni\Sbfnifront\Models\Sbfnifront;



class Notice extends Sbfnifront
{
    
    
    protected $connection   =   '';
    protected $table = 'notices';
    protected $guarded = [];
    //protected $fillable = [ 'columnOne', 'columnTwo', 'columnThree' ];
    /* Eloquent Relationship */
    ##ELOQUENTRELATIONSHIPMODEL##

}
