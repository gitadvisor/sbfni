<?php
namespace Breakit\Sbfni\Sbfnifront\Models;
        
use Breakit\Sbfni\Sbfnifront\Models\Sbfnifront;



class Event extends Sbfnifront
{
    
    
    protected $connection   =   '';
    protected $table = 'events';
    protected $guarded = [];
    //protected $fillable = [ 'columnOne', 'columnTwo', 'columnThree' ];
    /* Eloquent Relationship */
    ##ELOQUENTRELATIONSHIPMODEL##

}
